
package question1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Details implements ActionListener{
    JFrame frame;
    JTextField numberTextField;
    JTextField dayTextField;
    JTextField yearTextField;
    JTextField recoveryemail;
    
    JLabel numberlabel;
    JLabel daylabel;
    JLabel yearlabel;
    JLabel recoveryemaillabel;
    JLabel securelabel;
    JLabel birthLabel;
    JLabel label;
    JLabel phonenumber;
    JLabel phonenumberlabel;
    JLabel numberLabel;
   
    JComboBox MonthBox;
    JComboBox countrybox;
    JComboBox genderbox;
    
    JButton nextButton;
    JButton backButton;
    Details()
    {
       
        label = new JLabel();
        label.setText("Welcome to Google");
        label.setBounds(150, 20, 200, 50);
        label.setFont(new Font("oblique",Font.ITALIC,20));
        
        numberTextField = new JTextField();
        numberTextField.setBounds(250, 100, 150, 30);
        
        numberlabel = new JLabel();
        numberlabel.setText("Phone number (optional)");
        numberlabel.setBounds(110, 90, 150, 50);
        
        String[] countries = {"South Africa","American Samoa","Angola","Anguilla","DRC"};
        countrybox = new JComboBox(countries);
        countrybox.setBounds(5, 100, 100, 20);
        
        phonenumber = new JLabel();
        phonenumber.setBounds(5, 130,400 , 50);
        phonenumber.setText("Google will use this number only for account security.");
        phonenumber.setFont(new Font("null",Font.BOLD,10) );
       
        phonenumberlabel = new JLabel("your number wont be visible to others.");
        phonenumberlabel.setBounds(5, 140,400 , 50);
        phonenumberlabel.setFont(new Font("null",Font.BOLD,10) );
        
        numberLabel = new JLabel();
        numberLabel.setText("you can choose later whether to use it for other puposes.");
        numberLabel.setBounds(5, 150,400 , 50);
        numberLabel.setFont(new Font("null",Font.BOLD,10) );
     
        
        recoveryemail = new JTextField();
        recoveryemail.setBounds(200, 210, 200, 30);
        
        recoveryemaillabel = new JLabel();
        recoveryemaillabel.setText("Recovery email address (optional)");
        recoveryemaillabel.setBounds(5, 200, 200, 50);
        
        securelabel = new JLabel();
        securelabel.setText("we'll use it to keep your account secure");
        securelabel.setBounds(150, 250, 250, 20);
        securelabel.setBackground(Color.red);
        securelabel.setOpaque(true);
                
        dayTextField = new JTextField();
        dayTextField.setBounds(50, 350, 50, 50);
        
        daylabel = new JLabel();
        daylabel.setText("Day");
        daylabel.setBounds(5, 350, 100, 50);
        
        birthLabel = new JLabel();
        birthLabel.setText("your date of birth");
        birthLabel.setBounds(10, 390, 100, 50);
        
        String[] months = {"January", "February"," March","April","May"
        ,"June","July","August","september","october","November","December"};
        MonthBox = new JComboBox(months);
        MonthBox.setBounds(150,350, 100, 50);
        
        yearTextField = new JTextField();
        yearTextField.setBounds(350, 350, 100, 50);
        
        yearlabel = new JLabel();
        yearlabel.setText("Year");
        yearlabel.setBounds(320, 350, 150, 50);
        
        String[] gender = {"Male","Female","Rather not say","Custom"};
        genderbox = new JComboBox(gender);
        genderbox.setBounds(10, 450, 300, 50);
        
        nextButton = new JButton("Next");
        nextButton.setBounds(350, 600, 100,50);
        nextButton.setFocusable(false);
        nextButton.addActionListener(this);
                
        backButton = new JButton("Back");
        backButton.setBounds(10, 600, 100, 50);
        backButton.setFocusable(false);
        backButton.addActionListener(this);
        
        frame = new JFrame();
        frame.setSize(500, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLayout(null);
        frame.add(numberLabel);
        frame.add(phonenumberlabel);
        frame.add(phonenumber);
        frame.add(label);
        frame.add(backButton);
        frame.add(nextButton);
        frame.add(countrybox);
        frame.add(birthLabel);
        frame.add(genderbox);
        frame.add(yearlabel);
        frame.add(yearTextField);
        frame.add(MonthBox);
        frame.add(daylabel);
        frame.add(dayTextField);
        frame.add(securelabel);
        frame.add(recoveryemaillabel);
        frame.add(recoveryemail);
        frame.add(numberTextField);
        frame.add(numberlabel);
        
        frame.getContentPane().setBackground(Color.WHITE);
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource() == nextButton)
        {
            frame.dispose();
            new Sucess();
            
        }else if(e.getSource() ==  backButton)
        {
            frame.dispose();
            new question2();
        }
        
        
    }
}
