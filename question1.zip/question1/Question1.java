
package question1;


public class Question1 {
   
    
    public static void main(String[] args) {
        
        new question2();
    
    }
    
}
