
package question1;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Sucess implements ActionListener {
    
    JFrame frame;
    JLabel label;
    JButton SignInbutton;
    JButton cancelbutton;
    JPanel panel;
    Sucess()
    {
        SignInbutton = new JButton("Sing in");
        SignInbutton.setBounds(250, 200, 100, 50);
        SignInbutton.setFocusable(false);
        SignInbutton.addActionListener(this);
        
        cancelbutton = new JButton("Cancel");
        cancelbutton.setBounds(10, 200, 100, 50);
        cancelbutton.setFocusable(false);
        cancelbutton.addActionListener(this);
        
                
        label = new JLabel();
        label.setText("you have successfull created your email account");
        label.setFont(new Font("italy",Font.BOLD,15));
        
        panel = new JPanel();
        panel.setBounds(10, 40, 350, 50);
        panel.setForeground(Color.GRAY);
        panel.setOpaque(true);
        panel.add(label);
        
        frame = new JFrame();
        frame.getContentPane().setBackground(Color.white);
        frame.setSize(400, 300);
        frame.setLayout(null);
        frame.add(SignInbutton);
        frame.add(cancelbutton);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        frame.add(panel);
        
        frame.setVisible(true);
        
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() ==  SignInbutton)
        {
           frame.dispose();
           new  SignIn();
           
        }else if(e.getSource() == cancelbutton )
        {
            frame.dispose();
        }
    }
    
}
