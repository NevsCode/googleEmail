
package question1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class question2 implements ActionListener {
    
    JFrame frame;
    JLabel Emaillabel;
    JTextField EmailText;
    JLabel passwordlabel;
    JPasswordField passwordText;
    JButton nextbutton;
    JButton  JButton ;
    JLabel namelabel;
    JLabel surnamelabel;
    JTextField  nametext;
    JTextField surnametext;
    JLabel titlelabel;
    JLabel notelabel ;
    JLabel confirmPasswordLabel;
    JTextField confirmPasswordText;
    JLabel passwordNotelabel ;
    JPanel panel;
    JCheckBox checkBox;
    ImageIcon image;
    
    question2()
    {
        image = new ImageIcon("images.jpeg.jpg");
       
        checkBox = new JCheckBox("Show password");
        checkBox.setBounds(20, 300, 150, 20);
        checkBox.setFocusable(false);
        
        panel = new JPanel();
        panel.setBounds(5, 230, 500, 30);
        
        passwordNotelabel = new JLabel();
        passwordNotelabel.setText("use 8 or more characters with a mix of letters numbers & symbols ");
        passwordNotelabel.setBounds(20, 230, 300, 20);
        passwordNotelabel.setFont(new Font("null", Font.BOLD,15));
        passwordNotelabel.setForeground(Color.black);
        
        confirmPasswordLabel = new JLabel();
        confirmPasswordLabel.setText("Confirm");
        confirmPasswordLabel.setBounds(20, 200, 300, 25);
        confirmPasswordLabel.setFont(new Font("null", Font.ITALIC,15));
        confirmPasswordLabel.setForeground(Color.black);
        
        confirmPasswordText = new JTextField();
        confirmPasswordText.setBounds(160, 200, 165, 29);
        confirmPasswordText.setBackground(Color.white);
        confirmPasswordText.setForeground(Color.blue);
        
        notelabel = new JLabel();
        notelabel.setText("You can user letters,numbers & periods ");
        notelabel.setBounds(20, 125, 300, 25);
        notelabel.setFont(new Font("null", Font.BOLD,15));
        notelabel.setForeground(Color.black);
        
        titlelabel = new JLabel();
        titlelabel.setText("Create your Google Account");
        titlelabel.setBounds(20,1, 200, 25);
        titlelabel.setHorizontalTextPosition(JLabel.CENTER);
        titlelabel.setVerticalTextPosition(JLabel.TOP);
        titlelabel.setVerticalAlignment(JLabel.TOP);
        titlelabel.setLayout(new BorderLayout(10,10));
        titlelabel.setForeground(Color.blue);
        titlelabel.setFont(new Font(" null",Font.ITALIC,15));
        /*
        
        */
        Emaillabel = new JLabel("Enter your email");
        Emaillabel.setBounds(20, 100, 300, 25);
        Emaillabel.setFont(new Font("null", Font.ROMAN_BASELINE,15));
        Emaillabel.setForeground(Color.black);
        
        EmailText = new JTextField();
        EmailText.setBounds(160, 20, 165, 29);
        EmailText.setBackground(Color.white);
        EmailText.setForeground(Color.blue);
        /*
        
        */
        passwordlabel = new JLabel("Enter your password");
        passwordlabel.setBounds(20, 150, 300, 25);
        passwordlabel.setFont(new Font("null", Font.ROMAN_BASELINE,15));
        passwordlabel.setForeground(Color.black);
        
        passwordText = new JPasswordField();
        passwordText.setBounds(160, 150, 165, 30);
        passwordText.setBackground(Color.white);
        passwordText.setForeground(Color.blue);
        
        nametext = new JTextField();
        nametext.setBounds(160, 100, 165, 29);
        
        namelabel = new JLabel("Name");
        namelabel.setBounds(20, 20, 300, 25);
        namelabel.setFont(new Font("null", Font.ROMAN_BASELINE,15));
        namelabel.setForeground(Color.black);
        
        surnametext = new JTextField();
        surnametext.setBounds(160,60, 165, 30);
        surnametext.setBackground(Color.white);
        surnametext.setForeground(Color.blue);
        
        surnamelabel = new JLabel("Surname");
        surnamelabel.setBounds(20, 60, 300, 25);
        surnamelabel.setFont(new Font("null", Font.ROMAN_BASELINE,15));
        surnamelabel.setForeground(Color.black);
        
        nextbutton = new JButton("Next");
        nextbutton .addActionListener(this);
        nextbutton.setBounds(250,400, 100, 40);
        nextbutton.setFocusable(false);
        nextbutton.setBackground(Color.yellow);
        nextbutton.setOpaque(true);
        nextbutton.setLayout(new BorderLayout());
        
        frame = new JFrame();
        frame.setSize(500,500 );
        frame.setTitle("Email box");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.getContentPane().setBackground(Color.WHITE);
        frame.setLayout(null);
       
        frame.add(Emaillabel);
        frame.add(EmailText);
        frame.add(namelabel);
        frame.add(surnamelabel);
        frame.add(nametext);
        frame.add(surnametext);
        frame.add(titlelabel);
        frame.add(notelabel);
        frame.add(confirmPasswordLabel);
        frame.add(confirmPasswordText);
        frame.add(panel);
        panel.add(passwordNotelabel);
        frame.add(checkBox);
        frame.setIconImage(image.getImage());
        /*
        
        */
        frame.add(passwordlabel);
        frame.add(passwordText);
        /*
        
        */
        frame.add(nextbutton);        
        frame.setVisible(true);      
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource() == nextbutton )
        {
           frame.dispose();
           new Details();
        }
    }
    
}
