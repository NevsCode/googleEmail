
package question1;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class SignIn implements ActionListener{
    
    JFrame frame;
    JTextField emailfield;
    JPasswordField passwordfield;
    
    JLabel passwordlabel;  
    JLabel emaillabel;
    
    JButton Singbutton; 
    SignIn()
    {
        Singbutton = new JButton("Log in");
        Singbutton.setBounds(150, 300, 100, 50);
        Singbutton.setFocusable(false);
        Singbutton.addActionListener(this);
        
        emaillabel = new JLabel("Username");
        emaillabel.setBounds(40,100, 100, 50);
        
        emailfield = new JTextField();
        emailfield.setBounds(120, 100, 200,50);
        
        passwordlabel = new JLabel("Password");
        passwordlabel.setBounds(40,200,100, 50);
        
        passwordfield = new JPasswordField();
        passwordfield.setBounds(120, 200, 200, 50);
        
        frame = new JFrame();
        frame.getContentPane().setBackground(Color.white);
        frame.setSize(500, 500);
        frame.setLayout(null);
        frame.getContentPane().setBackground(Color.WHITE);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(Singbutton);
        frame.add(passwordlabel);
        frame.add(emaillabel);
        frame.add(emailfield);
        frame.add(passwordfield);
        frame.setVisible(true);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == Singbutton )
        {
            frame.dispose();
            JOptionPane.showMessageDialog(null,"Sucessfull");
        
        }else 
        {
            JOptionPane.showMessageDialog(null,"your username or password it incorerent");
        }
        
        
    }
    
}
